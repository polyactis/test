This directory contains the neural networks library for 

W.N. Venables and B.D. Ripley (2002) `Modern Applied Statistics
     with S' Fourth Edition. New York: Springer.

For fuller details use library(help=nnet)

The functions

    addNnetMenus()

sets up the menus and dialogs for the nnet libraries. These
are then available for use with subsequent sessions of that project,
but can be removed by the function

    removeNnetMenus()

Bill Venables  <Bill.Venables@cmis.csiro.au>
Brian Ripley   <ripley@stats.ox.ac.uk>

=================================================


Software for feed-forward neural networks with a single hidden layer.

nnet		fit neural network
predict.nnet	predict future observations.
print.nnet
summary.nnet
nnet.Hess	evaluate Hessian

which.is.max	select maximum of vector, breaking ties at random
class.ind	generates indicator matrix for factor



software for multinomial log-linear models

multinom
add1.multinom
anova.multinom
coef.multinom
deviance.multinom
drop1.multinom
extractAIC.multinom
fitted.multinom
formula.multinom
model.frame.multinom
predict.multinom
print.multinom
residuals.multinom
summary.multinom
vcov.multinom
