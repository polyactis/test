This directory contains the software and datasets for 

W.N. Venables and B.D. Ripley (2002) `Modern Applied Statistics with S' 
     Fourth Edition. New York: Springer.

To use the libraries use the File menu or the library function.
The functions

    addMassMenus(),  addNnetMenus()

set up the menus and dialogs for the MASS and nnet libraries. These
are then available for use with subsequent sessions of that project,
but can be removed by the functions

    removeMassMenus(),  removeNnetMenus()

Folder `scripts' contains the scripts for the fourth edition, and
`scripts3' those for the third edition.

The latest versions of these libraries will be available from mirrors
around the world: point your browser at

       http://www.stats.ox.ac.uk/pub/MASS4/

to find a site near you.

Bill Venables  <Bill.Venables@csiro.au>
Brian Ripley   <ripley@stats.ox.ac.uk>

==================================================================

functions (in chapter order)

write.matrix	write matrix or numeric data frame

ginv		generalized inverse

con2tr, mat2tr	convert to input for contourplot etc
eqscplot	equally-scaled plots

mvrnorm		simulate from a multivariate normal distribution
IQR		inter-quartile range
huber		Huber location with MAD scale
hubers		Huber proposal 2
truehist	histogram plots
histplot	Trellis histogram plots
nclass.FD	choose number of histogram classes
hist.scott	histogram with other bin choices
hist.FD		histogram with other bin choices
frequency.polygon
nclass.freq	choose number of classes for frequency polygon
ucv, bcv	cross-validation functions for density
width.SJ	bandwidth choice for density.
kde2d		2D kernel density estimation

boxcox		estimate Box-Cox transformation
logtrans	estimate shift in log-transformations
stdres		standardized residuals for linear models
studres		Studentized residuals for linear models
vcov		variance-covariance summary for linear, glm and 
		   non-linear regression fits
contr.sdif	contrasts function for successive differences
fractions	methods for operating on rational fractions

rlm		robust linear model fitting (by Huber M-estimator)
lqs		resistant regression
addterm		try all one-term additions to a model
dropterm	try all one-term deletions from a model
stepAIC		stepwise AIC minimization
lm.gls		generalized least squares fit
lm.ridge	ridge regression

dose.p		function for LD50-like fits
neg.bin		negative binomial family with fixed theta
anova.negbin	functions for full negative binomial family
glm.convert
glm.nb
negative.binomial
rnegbin
theta.md
theta.mm
loglm		Object-oriented wrapper for loglin
polr		proportional odds logistic regression
gamma.shape	MLE of shape parameter for GLM fit with gamma family
gamma.dispersion


deviance.nls	deviance function for nls fits
rms.curv	curvature measures for non-linear regression
plot.profile	enhanced plot method for profiles
vcov.nlregb	vcov methods for nlregb objects
ppr		projection-pursuit regression

sammon		Sammon non-linear mapping
isoMDS		isotonic multidimensional scaling
Shepard		Shepard plot for isoMDS
corresp		correspondence analysis
mca		multiple correspondence analysis

lda		linear discrimination
predict.lda	predict function for lda
qda		quadratic discrimination
predict.qda	predict function for qda
cov.rob 	robust estimation of multivariate location and scatter
cov.trob
max.col		find largest column for each row of a matrix,
		breaking ties at random

cpgram		cumulative periodogram
ARMAacf		theoretical ACF for ARMA processes
ARMAtoMA	infinite MA representation for ARMA processes
arima		full ML fitting of ARMA processes
tsdiag		diagnostics for arima

deriv3		symbolic differentiation
vcov.nlminb	vcov methods for nlminb objects


Datasets (in alphabetical order)

abbey		nickel in syenite rock
accdeaths	US accidental deaths 1973-8
Aids2		Australian AIDS survival data
Animals		body and brain weights from Rousseeuw & Leroy
anorexia	weight change data for young female anorexia patients
austres		quarterly series of the number of Australian residents
bacteria	presence of bacteria after drug treatments
beav1		time series of body temperatures of two beavers
beav2
biopsy		biopsies on breast cancer patients
birthwt		data on low birth weights for 189 babies from 
		   Hosmer & Lemeshow (1989)
Boston		the Boston housing data
cabbages	field trial of cabbages
caith		cross-tabulation of eye and hair colours in Caithness
Cars93		data from 93 cars on sale in the USA in 1993
cats		cat weights from Fisher (1947)
cement		dataset on heat evolved in setting cements
chem		copper in wholemeal flour
coop		co-operative trial in analytical chemistry
cpus		dataset on performance of cpus
crabs		measurements of Leptograpsus crabs
Cushings	tests on patients with Cushing's syndrome
DDT		DDT in kale
deaths		time-series on UK lung deaths 1974-9 from Diggle (1990)
mdeaths, fdeaths  as above, for males and females
drivers		time series on UK road deaths of drivers from Harvey (1989)
eagles		foraging behaviour of Bald Eagles
epil            seizure counts for epileptics
faithful	duration and waiting time for eruption from Old Faithful
farms		ecological farm management in Terschelling island
fgl		fragments of glass from forensic tests
forbes		Forbes' dataset on boiling points, from Atkinson
GAGurine	levels of GAG in urine of 314 children
galaxies	velocities of 82 galaxies, from Roeder (1990)
gehan		remission times on leukemia patients (censored)
genotype	rat genotype data
gilgais		line transect of soil in gilgai territory
hills		dataset on times of Scottish hill races
housing		Copenhagen housing conditions survey
immer		bivariate randomized block expt on barley
Insurance	numbers of car insurance claims by category
leuk		(uncensored) survival times on leukemia patients
lh		dataset on luteinizing hormone from Diggle
mammals		body weight(kg) and brain weight (g) of mammals, from Weisberg
mcycle		motorcycle impact data - Silverman JRSS B 1985
Melanoma	survival from melanomas from Andersen et al. (1993)
menarche	proportions of female children who have reached menarche
michelson	Michelson's measurements of the speed of light
minn38		status of Minnesota high-school leavers of 1938
motors		accelerated life testing on motorettes
muscle		effect of calcium chloride on muscle contraction in rat hearts
newcomb		passage times for light
nlschools       eighth-grade pupils in the Netherlands
nottem		time-series of temperatures in Nottingham, 1920-1939
npk		N,P,K factorial experiment on peas
npr1		US Naval Petroleum Reserve 1 dataset
oats		split-plot field trial of oat varieties
OME		tests of auditory perception in children with OME
painters	de Piles' scores of painters
petrol		Prater's data on the refining of oil
phones		Belgian 'phone calls 1950-1973
Pima.tr		diabetes in Pima Indians -- training data
Pima.te		diabetes in Pima Indians -- test data
quine		school absences from Aitkin (1978)
Rabbit		blood pressure experiments on rabbits
road		road deaths by state in the USA
rock            measurements on Petroleum Rock Samples
rotifer		numbers of rotifers of two species vs fluid density
Rubber		dataset on rubber wear
ships		ship damage incidents, from McCullagh & Nelder (1989)
shrimp		shrimp in shrimp cocktail
shuttle		decision tree problem from Michie (1989)
Sitka		growth curve data for Sitka trees from Diggle et al. (1994)
Sitka89		ditto for the trees in 1989
Skye		AFM compositions of aphyric Skye lavas
snails		snail mortailty data
SP500		S&P500 closing prices for the 1990s
steam		steam pressure data from Draper & Smith (1981)
stormer		Stormer viscometer calibration data from Williams (1959)
survey		survey of Adelaide University students
synth.tr	synthetic classification problem -- training data
synth.te	synthetic classification problem -- test data
topo		topographic dataset
Traffic		effect of Swedish speed limits on accidents
trees		volume of Black cherry trees vs diameter and height
UScereal	nutritional and marketing information on US cereals
UScrime		the effect of punishment regimes on crime rates
waders		wader counts in South Africa
whiteside	energy consumption in a domestic house
wtloss		weight loss by an obese patient
